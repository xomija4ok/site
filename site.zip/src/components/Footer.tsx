export default function Footer() {
  return (
    <footer className="relative z-10 border-t border-white/5 px-5 py-12 text-center">
      <div className="mx-auto max-w-6xl">
        <div className="font-display text-xs font-bold tracking-[0.4em] text-zinc-500">FHUB</div>
        <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-600">
          ХВХ Клан · SP / FT
        </div>

        <div className="credit-glow mt-9 text-xs font-semibold text-zinc-400/60">
          by dark (@dark_possible)
        </div>
      </div>
    </footer>
  );
}
