import { motion } from "framer-motion";
import { ArrowUpRight, ChevronDown, Scroll } from "lucide-react";
import { DiscordIcon } from "./DiscordIcon";
import { EASE } from "./ui";
import heroBg from "../assets/hero-aurora.jpg";
import { DISCORD_INVITE, openDiscord } from "../utils/discord";

const stats = [
  { value: "SP / FT", label: "Сервера" },
  { value: "24 / 7", label: "Онлайн клана" },
];

export default function Hero() {
  const letters = "FHUB".split("");

  return (
    <section
      id="top"
      className="relative flex min-h-svh flex-col items-center justify-center overflow-hidden px-5 pb-28 pt-36 text-center"
    >
      <img
        src={heroBg}
        alt=""
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-40 [mask-image:radial-gradient(82%_72%_at_50%_42%,black_22%,transparent_100%)]"
      />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-ink-950 to-transparent" />

      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: EASE, delay: 0.1 }}
        className="relative z-10 inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-5 py-2 text-[10px] font-extrabold uppercase tracking-[0.32em] text-zinc-300 backdrop-blur-md md:text-[11px]"
      >
        <span className="animate-pulse-dot relative h-1.5 w-1.5 rounded-full bg-accent-400" />
        Идёт набор в клан
        <Scroll className="h-3.5 w-3.5 text-accent-300" />
      </motion.div>

      <motion.h1
        initial="hidden"
        animate="show"
        variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1, delayChildren: 0.3 } } }}
        className="relative z-10 mt-9 flex select-none justify-center font-display text-[clamp(4.2rem,18vw,12.5rem)] font-extrabold leading-[1.02] tracking-tight"
        aria-label="FHUB"
      >
        {letters.map((l, i) => (
          <span key={i} className="overflow-hidden pb-[0.1em]">
            <motion.span
              variants={{
                hidden: { y: "115%" },
                show: { y: "0%", transition: { duration: 1.1, ease: EASE } },
              }}
              className="hero-title block"
            >
              {l}
            </motion.span>
          </span>
        ))}
      </motion.h1>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: EASE, delay: 0.85 }}
        className="relative z-10 mt-5 flex items-center justify-center gap-4"
      >
        <span className="h-px w-10 bg-gradient-to-r from-transparent to-accent-400/60 md:w-20" />
        <span className="font-display text-[10px] font-medium uppercase tracking-[0.45em] text-accent-300 md:text-xs">
          Сильнейший ХВХ клан · SP / FT
        </span>
        <span className="h-px w-10 bg-gradient-to-l from-transparent to-accent-400/60 md:w-20" />
      </motion.div>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: EASE, delay: 1 }}
        className="relative z-10 mt-7 max-w-xl text-sm leading-relaxed text-zinc-400 md:text-base"
      >
        Мы собираем сильнейших игроков для доминации на сервере. Дружная тима, стабильный
        онлайн, помощь в замесах и сетки на весь состав — это FHUB.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: EASE, delay: 1.12 }}
        className="relative z-10 mt-10 flex flex-col items-center gap-4 sm:flex-row"
      >
        <a
          href={DISCORD_INVITE}
          target="_blank"
          rel="noopener noreferrer"
          referrerPolicy="no-referrer"
          onClick={openDiscord}
          className="group relative inline-flex items-center gap-2.5 overflow-hidden rounded-full bg-gradient-to-r from-accent-500 to-accent-600 px-7 py-3.5 text-sm font-extrabold text-white shadow-[0_10px_44px_-8px_rgba(143,123,255,0.65)] transition-all duration-300 hover:scale-[1.04] hover:shadow-[0_10px_56px_-6px_rgba(143,123,255,0.85)]"
        >
          <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
          <DiscordIcon className="h-5 w-5" />
          Вступить в Discord
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
        </a>
        <a
          href="#requirements"
          className="glass inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold text-zinc-300 transition-all duration-300 hover:border-white/20 hover:text-white"
        >
          Что мы требуем
          <ChevronDown className="h-4 w-4 text-accent-300" />
        </a>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: EASE, delay: 1.28 }}
        className="relative z-10 mt-16 grid w-full max-w-xl grid-cols-2 divide-x divide-white/5 rounded-3xl border border-white/5 bg-white/[0.02] py-5 backdrop-blur-md md:py-6"
      >
        {stats.map((s) => (
          <div key={s.label} className="px-2">
            <div className="font-display text-base font-bold text-white md:text-2xl">{s.value}</div>
            <div className="mt-1.5 text-[9px] font-bold uppercase tracking-[0.25em] text-zinc-500 md:text-[10px]">
              {s.label}
            </div>
          </div>
        ))}
      </motion.div>

      <motion.a
        href="#promises"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.7, duration: 1 }}
        className="absolute bottom-6 z-10 flex flex-col items-center gap-1.5 text-zinc-500 transition-colors hover:text-zinc-300"
      >
        <span className="text-[9px] font-extrabold uppercase tracking-[0.4em]">Листай вниз</span>
        <ChevronDown className="h-4 w-4 animate-bounce" />
      </motion.a>
    </section>
  );
}
