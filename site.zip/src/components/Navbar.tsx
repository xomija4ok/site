import { useEffect, useState } from "react";
import { DiscordIcon } from "./DiscordIcon";
import { DISCORD_INVITE, openDiscord } from "../utils/discord";

const links = [
  { href: "#promises", label: "Обещания" },
  { href: "#requirements", label: "Требования" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "border-b border-white/5 bg-ink-950/70 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:h-[72px] md:px-8">
        <a href="#top" className="group flex items-center gap-3">
          <span className="relative grid h-8 w-8 place-items-center">
            <span className="absolute inset-0 rotate-45 rounded-[10px] bg-gradient-to-br from-accent-400 to-accent-600 shadow-[0_0_18px_rgba(143,123,255,0.55)] transition-transform duration-500 group-hover:rotate-[135deg]" />
            <span className="relative font-display text-[11px] font-extrabold text-ink-950">F</span>
          </span>
          <span className="font-display text-sm font-bold tracking-[0.3em] text-white">FHUB</span>
        </a>

        <div className="hidden items-center gap-9 md:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-[13px] font-bold tracking-wide text-zinc-400 transition-colors duration-300 hover:text-white"
            >
              {l.label}
            </a>
          ))}
        </div>

        <a
          href={DISCORD_INVITE}
          target="_blank"
          rel="noopener noreferrer"
          referrerPolicy="no-referrer"
          onClick={openDiscord}
          className="flex items-center gap-2 rounded-full border border-accent-500/30 bg-accent-500/10 px-4 py-2 text-[13px] font-extrabold text-accent-200 transition-all duration-300 hover:border-accent-400/50 hover:bg-accent-500/20 hover:shadow-[0_0_28px_rgba(143,123,255,0.4)]"
        >
          <DiscordIcon className="h-4 w-4" />
          <span className="hidden sm:inline">Discord клана</span>
          <span className="sm:hidden">Discord</span>
        </a>
      </nav>
    </header>
  );
}
