import { Activity, Share2, Swords, Users, type LucideIcon } from "lucide-react";
import { Reveal, SectionHead } from "./ui";

const items: { icon: LucideIcon; title: string; desc: string }[] = [
  {
    icon: Users,
    title: "Общительная тима",
    desc: "Хорошая, активная команда, с которой приятно общаться и играть изо дня в день.",
  },
  {
    icon: Swords,
    title: "Хелпа на замесах",
    desc: "Гарантированная поддержка на ивентах и в PvP-замесах — один в поле не воин.",
  },
  {
    icon: Activity,
    title: "Стабильный онлайн",
    desc: "Каждый день стабильный онлайн состава — тебя всегда есть кому подстраховать.",
  },
  {
    icon: Share2,
    title: "Делимся сетками",
    desc: "Обмениваемся сетками между участниками — общий прогресс клана прежде всего.",
  },
];

export default function Promises() {
  return (
    <section id="promises" className="relative scroll-mt-24 px-5 py-24 md:py-32">
      <div className="mx-auto max-w-6xl">
        <SectionHead
          index="01"
          label="Обещания"
          title={
            <>
              Что мы <span className="text-accent-gradient">обещаем</span>
            </>
          }
          sub="Четыре столпа, на которых держится FHUB. Это клан даёт каждому участнику."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 md:gap-5 lg:grid-cols-4">
          {items.map((item, i) => {
            const Icon = item.icon;
            return (
              <Reveal key={item.title} delay={i * 0.08} className="h-full">
                <div className="group glass relative h-full overflow-hidden rounded-3xl p-7 transition-all duration-500 hover:-translate-y-2 hover:border-accent-500/25 hover:shadow-[0_24px_70px_-24px_rgba(143,123,255,0.45)]">
                  <span className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent-400/60 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                  <div className="pointer-events-none absolute -right-14 -top-14 h-36 w-36 rounded-full bg-accent-500/0 blur-3xl transition-colors duration-500 group-hover:bg-accent-500/15" />

                  <div className="relative">
                    <div className="flex items-center justify-between">
                      <span className="grid h-12 w-12 place-items-center rounded-2xl border border-accent-500/25 bg-accent-500/10 text-accent-300 transition-all duration-500 group-hover:bg-accent-500/20 group-hover:text-accent-200">
                        <Icon className="h-5 w-5" />
                      </span>
                      <span className="font-display text-sm font-medium text-white/15">
                        0{i + 1}
                      </span>
                    </div>
                    <h3 className="mt-6 text-lg font-bold text-white">{item.title}</h3>
                    <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">{item.desc}</p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
