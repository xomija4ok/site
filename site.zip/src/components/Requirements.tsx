import {
  Cpu,
  Headphones,
  HeartHandshake,
  LayoutGrid,
  Mic,
  Swords,
  type LucideIcon,
} from "lucide-react";
import { Reveal, SectionHead } from "./ui";

const items: { icon: LucideIcon; title: string; desc: string }[] = [
  {
    icon: Cpu,
    title: "Платный чит",
    desc: "Обязателен платный чит на версию 1.21 — желательно Wild или Britva.",
  },
  {
    icon: HeartHandshake,
    title: "Адекватность",
    desc: "Спокойное и вменяемое поведение. Уважаем тиммейтов и репутацию клана.",
  },
  {
    icon: Swords,
    title: "Умение играть",
    desc: "Уверенно дерёшься и вовремя хелпуешь тиме в замесах и на ивентах.",
  },
  {
    icon: Mic,
    title: "Рабочий микрофон",
    desc: "Микрофон всегда в порядке — чёткая связь решает исход замеса.",
  },
  {
    icon: LayoutGrid,
    title: "Сетки каждый день",
    desc: "По возможности собираешь сетки ежедневно для общего прогресса клана.",
  },
  {
    icon: Headphones,
    title: "Актив в войсе",
    desc: "Находишься в голосовом канале каждый день — минимум 2 часа.",
  },
];

export default function Requirements() {
  return (
    <section id="requirements" className="relative scroll-mt-24 px-5 py-24 md:py-32">
      <div className="mx-auto max-w-6xl">
        <SectionHead
          index="02"
          label="Требования"
          title={
            <>
              Что мы <span className="text-accent-gradient">требуем</span>
            </>
          }
          sub="Шесть простых условий для вступления. Если подходишь — добро пожаловать в состав."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 md:gap-5 lg:grid-cols-3">
          {items.map((item, i) => {
            const Icon = item.icon;
            return (
              <Reveal key={item.title} delay={(i % 3) * 0.08} className="h-full">
                <div className="group glass relative flex h-full items-start gap-5 overflow-hidden rounded-3xl p-6 transition-all duration-500 hover:-translate-y-1.5 hover:border-accent-500/25 hover:shadow-[0_20px_60px_-22px_rgba(143,123,255,0.4)] md:p-7">
                  <span className="absolute inset-y-0 left-0 w-px bg-gradient-to-b from-transparent via-accent-400/60 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-accent-500/25 bg-accent-500/10 text-accent-300 transition-all duration-500 group-hover:bg-accent-500/20 group-hover:text-accent-200">
                    <Icon className="h-5 w-5" />
                  </span>

                  <div className="min-w-0">
                    <div className="flex items-baseline gap-2.5">
                      <h3 className="text-base font-bold text-white">{item.title}</h3>
                      <span className="font-display text-[11px] font-medium text-white/20">
                        / 0{i + 1}
                      </span>
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-zinc-400">{item.desc}</p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
