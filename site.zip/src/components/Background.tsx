import { motion, useMotionValue, useSpring } from "framer-motion";
import { useEffect } from "react";

export default function Background() {
  const x = useMotionValue(-800);
  const y = useMotionValue(-800);
  const sx = useSpring(x, { stiffness: 55, damping: 18 });
  const sy = useSpring(y, { stiffness: 55, damping: 18 });

  useEffect(() => {
    const move = (e: MouseEvent) => {
      x.set(e.clientX - 300);
      y.set(e.clientY - 300);
    };
    window.addEventListener("mousemove", move, { passive: true });
    return () => window.removeEventListener("mousemove", move);
  }, [x, y]);

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
      {/* base wash */}
      <div className="absolute inset-0 bg-[radial-gradient(120%_85%_at_50%_0%,#141627_0%,#0a0b10_58%)]" />

      {/* floating glow orbs */}
      <div className="animate-float-slow absolute -top-44 left-1/2 h-[36rem] w-[58rem] -translate-x-1/2 rounded-full bg-accent-500/10 blur-[140px]" />
      <div className="animate-float-slow absolute -left-48 top-[36%] h-[26rem] w-[26rem] rounded-full bg-accent-600/10 blur-[120px] [animation-delay:-7s]" />
      <div className="animate-float-slow absolute -right-40 bottom-[-12%] h-[30rem] w-[30rem] rounded-full bg-[#4c6fff]/8 blur-[130px] [animation-delay:-12s]" />

      {/* mouse-follow glow */}
      <motion.div
        className="absolute hidden h-[600px] w-[600px] rounded-full md:block"
        style={{
          x: sx,
          y: sy,
          background: "radial-gradient(circle, rgba(143,123,255,0.07) 0%, transparent 62%)",
        }}
      />

      {/* grid */}
      <div
        className="bg-grid absolute inset-0 opacity-60"
        style={{ maskImage: "radial-gradient(75% 60% at 50% 35%, black, transparent)" }}
      />

      {/* film grain */}
      <div className="noise absolute inset-0 opacity-[0.05]" />
    </div>
  );
}
