const items = [
  "FHUB",
  "ХВХ Клан",
  "SP / FT",
  "Стабильный онлайн",
  "Хелпа на замесах",
  "Делимся сетками",
];

export default function Marquee() {
  const row = (
    <div className="flex shrink-0 items-center gap-10 pr-10 md:gap-14 md:pr-14">
      {items.map((t, i) => (
        <span key={i} className="flex items-center gap-10 md:gap-14">
          <span className="whitespace-nowrap font-display text-[11px] font-medium uppercase tracking-[0.4em] text-zinc-500 md:text-xs">
            {t}
          </span>
          <span className="h-1.5 w-1.5 rotate-45 bg-accent-500/60" />
        </span>
      ))}
    </div>
  );

  return (
    <section className="relative overflow-hidden border-y border-white/5 bg-white/[0.015] py-5 md:py-6">
      <div className="animate-marquee flex w-max hover:[animation-play-state:paused]">
        {row}
        {row}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-ink-950 to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-ink-950 to-transparent" />
    </section>
  );
}
