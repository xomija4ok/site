import Background from "./components/Background";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import Promises from "./components/Promises";
import Requirements from "./components/Requirements";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="relative min-h-svh overflow-x-clip bg-ink-950 font-sans text-zinc-100 antialiased">
      <Background />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <Marquee />
        <Promises />
        <Requirements />
      </main>
      <Footer />
    </div>
  );
}
