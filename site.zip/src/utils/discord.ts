import type { MouseEvent } from "react";

export const DISCORD_INVITE = "https://discord.com/invite/SM5j5wXyzF";

/**
 * Гарантированно открывает инвайт Discord в НОВОЙ вкладке браузера.
 *
 * Проблема: внутри встроенного превью (sandbox-iframe без allow-popups)
 * браузер молча превращает target="_blank" в навигацию самого iframe,
 * а Discord отдаёт X-Frame-Options: DENY -> ERR_BLOCKED_BY_RESPONSE.
 *
 * Логика:
 *  1. Сайт открыт в обычной вкладке — ничего не перехватываем,
 *     работает стандартный <a target="_blank" rel="noopener noreferrer">.
 *  2. Сайт внутри iframe/превью — пробуем popup в новую вкладку.
 *  3. Если popup заблокирован (вернул null) — выходим из песочницы
 *     верхнеуровневой навигацией по window.top.
 */
export function openDiscord(e: MouseEvent<HTMLAnchorElement>) {
  let isFramed = false;
  try {
    isFramed = window.self !== window.top;
  } catch {
    // cross-origin window.top доступ закрыт — значит мы точно во фрейме
    isFramed = true;
  }

  // 1. Обычное окно браузера — нативное поведение ссылки
  if (!isFramed) return;

  // 2. Встроенное превью: пытаемся открыть настоящую новую вкладку
  e.preventDefault();

  const popup = window.open(DISCORD_INVITE, "_blank", "noopener,noreferrer");
  if (popup) {
    popup.focus?.();
    return;
  }

  // 3. Popup заблокирован песочницей — выходим из iframe на верхний уровень
  try {
    window.top?.location.assign(DISCORD_INVITE);
  } catch {
    window.location.assign(DISCORD_INVITE);
  }
}
